from django.apps import AppConfig


class Argon1Config(AppConfig):
    name = 'argon1'
